using UnityEngine;
using UnityEngine.UI;



namespace Pacman
{
    public class LivesView : MonoBehaviour
    {
        [SerializeField] private Text m_LivesText;

        public void UpdateLives(int lives)
        {
            if (m_LivesText)
                m_LivesText.text = $"Lives: {lives}";
        }
    }
}
